TELEGRAM NFT GIFTS SIMULATOR — Android project

Что это:
Офлайн-игра-симулятор с магазином виртуальных подарков, коллекцией,
игровыми монетами, энергией и продажей предметов.

Как получить APK:
1. Установите Android Studio.
2. Откройте в Android Studio папку TelegramNFTGiftsAndroid.
3. Дождитесь синхронизации Gradle.
4. Выберите Build -> Build Bundle(s) / APK(s) -> Build APK(s).
5. APK появится в app/build/outputs/apk/debug/app-debug.apk.

Для публикации в Google Play потребуется собственная подпись release-сборки.
Приложение не подключается к Telegram, TON или реальным NFT. Названия подарков
используются только для фанатского игрового симулятора.
